let sX = 275;
let sY = 275;
let sW = 50;
let moX = 0;
let moY = 0;
let up = true;
let left = true;
function setup() {
  createCanvas(600, 600);
  frameRate(20);
  colorMode(RGB, 255, 255, 255, 1);
}

function draw() {
  background(200);
  fill(color(220, 50, 40));
  square(sX, sY, sW/2); //top left
  fill(color(40, 220, 50));
  square(sX+sW/2, sY, sW/2); //top right
  fill(color(40, 50, 220));
  square(sX, sY+sW/2, sW/2); //bottom left
  fill(color(190, 180, 40));
  square(sX+sW/2, sY+sW/2, sW/2);  //bottom right
  moX = floor(moX);
  moY = floor(moY);
  if (mouseX != pmouseX) {
    moX += sqrt(dist(mouseX, 0, pmouseX, 0));
    if (mouseX > pmouseX) {
      left = false;
    }
  }
  if (mouseY != pmouseY) {
    moY += sqrt(dist(mouseY, 0, pmouseY, 0));
    if (mouseY > pmouseY) {
      up = false;
    }
  }
  if (left) {
    sX -= moX;
    if (sX < 0) {
      sX = 0;
      left = false;
    }
  }
  else {
    sX += moX
    if (sX > 549) {
      sX = 549;
      left = true;
    }
  }
  if (up) {
    sY -= moY;
    if (sY < 0) {
      sY = 0;
      up = false;
    }
  }
  else {
    sY += moY
    if (sY > 549) {
      sY = 549;
      up = true;
    }
  }
  if (moX > 0) {
    moX -= 1;
  }
  if (moY > 0) {
    moY -= 1;
  }
  console.log(moY + ", " + moX);
}