let dir;
let cX;
let cY;
function setup() {
  createCanvas(512, 512);
  colorMode(RGB, 255, 255, 255);
  dir = floor(random(0, 8));
  cX = floor(random(49, 462));
  cY = floor(random(49, 462));
  console.log(dir);
}

function draw() {
  background(220);
  fill(color(240, 170, 70));
  stroke(color(180, 145, 30));
  strokeWeight(3);
  circle(cX, cY, 60);
  if (dir > 0 && dir < 4) {
    cX++;
  }
  else if (dir > 4) {
    cX--;
  }
  if (dir < 2 || dir > 6) {
    cY--;
  }
  else if (dir > 2 && dir < 6) {
    cY++;
  }
  if (cX > 541 || cX < -30 || cY > 541 || cY < -30) {
    dir = floor(random(0, 8));
    cX = floor(random(49, 462));
    cY = floor(random(49, 462));
    console.log(dir);
  }
}