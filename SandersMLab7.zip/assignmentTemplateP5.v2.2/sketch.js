let a1 = [];
let a2 = [];
function setup() {
  createCanvas(400, 400);
  background(220);
  for (let i = 0; i < 5; i++) {
    a1.push(int(random(0, 10)));
    a2.push(float(random(0, 10).toFixed(4)));
  }
  console.log(a1);
  console.log(a2);
  let a3 = [];
  for (let i = 0; i < 10; i++) {
    if (i < 5) {
      a3.push(a1[i]);
    }
    else {
      a3.push(a2[i-5]);
    }
  }
  console.log(a3);
  text(a1, 50, 70);
  text(a2, 50, 140);
  text(a1[int(random(0, 4))], 50, 210);
  text(a2[int(random(0, 4))], 50, 280);
  text(a3[int(random(0, 9))], 50, 350);
}

function draw() {
  
}