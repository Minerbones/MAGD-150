let momentum = 0;
let birdY = 250;
let active = false;
let speed = 4;
let score = 0;
let pipe1X = 800;
let pipe1Y;
let pipe2X = 1200;
let pipe2Y;
let birdX = 50;
let pipe1point = false;
let pipe2point = false;
function setup() {
  createCanvas(650, 500);
  colorMode(RGB, 255, 255, 255);
  frameRate(30);
  pipe1Y = random(75, 425);
  pipe2Y = random(75, 425);
  environment();
  bird(birdX, birdY);
}

function draw() {
  if (active) {
    environment();
    bird(birdX, birdY);
    birdY += momentum;
    momentum++;
    pipe(pipe1X, pipe1Y);
    pipe(pipe2X, pipe2Y);
    pipe1X -= speed;
    pipe2X -= speed;
    if (pipe1X <= -50) {
      pipe1X = 750;
      pipe1Y = random(75, 425);
      pipe1point = false;
    }
    else if (pipe2X <= -50) {
      pipe2X = 750;
      pipe2Y = random(75, 425);
      pipe2point = false;
    }
    fill(color(210, 210, 70));
    textSize(28);
    text(score, 325, 25);
    if (birdY < 15 || birdY > 485) {
      lose();
    }
    else if (abs(birdY-pipe1Y) > 35 && abs(birdX-pipe1X) < 35) {
      lose();
    }
    else if (abs(birdY-pipe2Y) > 35 && abs(birdX-pipe2X) < 35) {
      lose();
    }
    if (pipe1X < birdX && !pipe1point) {
      score++;
      pipe1point = true;
      if (score % 5 == 0) {
        speed++;
      }
    }
    if (pipe2X < birdX && !pipe2point) {
      score++;
      pipe2point = true;
      if (score % 5 == 0) {
        speed++;
      }
    }
  }
  else {
    fill(color(0,0,0));
    textSize(30);
    text('Click or press Space to play', 150, 250);
  }
}

function bird(x, y) {
  fill(color(240, 240, 70));
  stroke(color(0, 0, 0));
  strokeWeight(1);
  circle(x, y, 30);
  fill(color(255, 255, 255));
  stroke(color(0, 0, 0));
  strokeWeight(1);
  circle(x+7, y-5, 12);
  fill(color(0, 0, 0));
  stroke(color(0, 0, 0));
  strokeWeight(1);
  circle(x+9, y-5, 4);
}

function pipe(x, y) {
  let size = 100;
  fill(color(50, 199, 40));
  stroke(color(0, 0, 0));
  strokeWeight(1);
  rect(x-20, 0, 40, (y-size/2));
  rect(x-25, (y-size/2)-10, 50, 10);
  rect(x-20, (y+size/2), 40, (500-y-size/2));
  rect(x-25, (y+size/2), 50, 10);
}

function environment() {
  background(color(185, 185, 255));
  clouds();
  hills();
}

function clouds() {
  let cloudX = (frameCount % 650) - 650;
  let cloudY;
  let sway;
  let diff = 0;
  while (cloudX < 675) {
    fill(color(250, 250, 250));
    noStroke();
    sway = ((cloudX+100) % 20);
    if (sway > 10) {
      sway = 20 - sway;
    }
    cloudY = 100 + sway + diff;
    circle(cloudX, cloudY, 40);
    circle(cloudX+10, cloudY-22, 40);
    circle(cloudX+24, cloudY+9, 40);
    circle(cloudX+32, cloudY-14, 40);
    circle(cloudX+45, cloudY+8, 40);
    cloudX += 200;
    if (diff == 0) {
      diff += 75;
    }
    else {
      diff = 0;
    }
  }
}

function hills() {
  let hillY = [80, 95, 90, 105, 100, 95, 115, 120, 110, 100, 90, 85, 80];
  fill(color(195, 160, 125));
  for (let i = 0; i < 13; i++) {
    ellipse(i*50 + 25, (500 - hillY[i]), 80, 50);
    rect(i*50, (500 - hillY[i]), 50, 500);
  }
}

function mouseClicked() {
  if (active) {
    momentum = -8;
  }
  else {
    active = true;
    momentum = -3;
  }
}

function keyPressed() {
  if (keyCode == 32) {
    if (active) {
      momentum = -8;
    }
    else {
      active = true;
      momentum = -3;
    }
  }
}

function lose() {
  active = false;
  birdY = 250;
  pipes1point = false;
  pipes2point = false;
  console.log(score);
  score = 0;
  speed = 4;
  pipe1X = 750;
  pipe1Y = random(100, 400);
  pipe2X = 1150;
  pipe2Y = random(100, 400);
}