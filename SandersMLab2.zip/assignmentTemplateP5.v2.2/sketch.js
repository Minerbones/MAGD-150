function setup() {
  createCanvas(400, 400);
  background(200);
  colorMode(RGB, 255, 255, 255, 100);
}

function draw() {
  balloons();
}

function balloons() {
  balloon(190, 90, 220, 20, 50);
  balloon(250, 100, 200, 20, 180);
  balloon(115, 105, 250, 150, 150);
  balloon(150, 140, 20, 220, 30);
  balloon(235, 205, 230, 230, 25);
  balloon(220, 150, 20, 110, 220);
  balloon(130, 190, 225, 155, 20);
}

function balloon(x, y, r, g, b) {
  let c = color(r, g, b, 95);
  let cBorder = color(r-20, g-20, b-20, 99);
  let shine = color(r+20, g+20, b+20, 87);
  stroke(50);
  strokeWeight(3);
  noFill();
  if (x > 200) {
    bezier(x, y+95,  
         x-5, 400,
         x-25, y+(400-y)/2,
         200, 400);
  }
  else {
    bezier(x, y+95,  
         x+5, 400,
         x+25, y+(400-y)/2,
         200, 400);
  }
  
  fill(c);
  strokeWeight(3);
  stroke(cBorder);
  triangle(x, y+80, x-15, y+98, x+15, y+98);
  strokeWeight(5);
  ellipse(x, y, 125, 175);
  stroke(shine);
  strokeWeight(10);
  noFill();
  arc(x, y, 80, 130, 1.6*PI, 1.9*PI);
}